import { createApp } from 'vue'
import App from './App.vue'
import style from './assets/style.css'

createApp(App).mount('#app')
