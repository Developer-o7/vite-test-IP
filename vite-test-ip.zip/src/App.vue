<script>
import axios from "axios";
export default {
  methods: {
    async newAdd() {
      this.saveData()
      this.showLoaded = !this.showLoaded
      this.showText = !this.showText
    },

    async saveData() {
      try {
        const getIP = await axios
          .get('http://universities.hipolabs.com/search?country=Uzbekistan')
          .then((res) => {
            console.log(res.data)
            this.name = res.data.name
          });
      } catch (error) {
        console.log(error);
      }
    },
  },

  data() {
    return {
      name: "",
      domains: "",
      country: "",
      showText: false,
      showLoaded: true,
      queryIP: '',
      data: []
    };
  },
};
</script>

<template>
  <br />
  <div class="container card">
    <label for="text" class="City">Enter your country</label>
    <div class="input-group mb-3">
      <input
        :v-modal="queryIP"
        type="text"
        class="form-control rounded"
        placeholder="region"
        aria-label="Recipient's username"
        aria-describedby="button-addon2"
      />

      <button
        class="btn btn-outline-primary"
        type="button"
        id="button-addon2"
        @click.enter="newAdd()"
      >
        Click me
      </button>
    </div>
  </div>

  <!-- loaded -->
  <div v-if="showLoaded" class="lds-spinner">
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
  </div>

  <div v-if="showText" class="container card-group pt-5">
    <div class="card m-2">
      <p>NAME:</p>
      <h2 v-if="this.name !== ''">
        <li v-for="dat in data" :key="dat.name">{{ dat.name }}</li>
      </h2>
      <div v-else class="lds-ring">
        <div></div>
        <div></div>
        <div></div>
        <div></div>
      </div>
    </div>
    <div class="card m-2">
      <p>DOMAINS:</p>
      <h2 v-if="this.domains !== ''">{{ domains }}</h2>
      <div v-else class="lds-ring">
        <div></div>
        <div></div>
        <div></div>
        <div></div>
      </div>
    </div>
    <div class="card m-2">
      <p>COUNTRY:</p>
      <h2 v-if="this.country !== ''">{{ country }}</h2>
      <div v-else class="lds-ring">
        <div></div>
        <div></div>
        <div></div>
        <div></div>
      </div>
    </div>
  </div>
</template>
